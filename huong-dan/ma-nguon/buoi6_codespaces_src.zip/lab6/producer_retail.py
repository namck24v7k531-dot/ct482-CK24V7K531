"""Producer mô phỏng luồng giao dịch bán lẻ thời gian thực (Buổi 6 - CT482).

Đọc tuần tự retail_transactions.csv, thay cột ts bằng thời điểm hiện tại (UTC, ISO-8601)
và gửi từng giao dịch dạng JSON vào Kafka, khóa (key) = store_id.
"""
import argparse
import csv
import json
import random
import time
from collections import Counter
from datetime import datetime, timedelta, timezone

from kafka import KafkaProducer

parser = argparse.ArgumentParser()
parser.add_argument("--csv", default="/data/retail_transactions.csv")
parser.add_argument("--bootstrap", default="kafka:9092",
                    help="kafka:9092 khi chạy trong container; localhost:9092 khi chạy trên máy host")
parser.add_argument("--topic", default="retail-transactions")
parser.add_argument("--sleep", type=float, default=0.2, help="số giây nghỉ giữa hai bản ghi")
parser.add_argument("--limit", type=int, default=2000, help="số bản ghi sẽ gửi")
parser.add_argument("--skip", type=int, default=0, help="bỏ qua N dòng đầu của CSV")
parser.add_argument("--late-ratio", type=float, default=0.0, help="tỉ lệ bản ghi bị lùi thời gian")
parser.add_argument("--late-minutes", type=int, default=8, help="số phút lùi lại cho bản ghi đến muộn")
args = parser.parse_args()

producer = KafkaProducer(
    bootstrap_servers=args.bootstrap,
    value_serializer=lambda v: json.dumps(v).encode("utf-8"),
    key_serializer=lambda k: str(k).encode("utf-8"),
)

futures = []
with open(args.csv, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    sent = 0
    for i, row in enumerate(reader):
        if i < args.skip:
            continue
        if sent >= args.limit:
            break
        now = datetime.now(timezone.utc)
        if random.random() < args.late_ratio:
            now = now - timedelta(minutes=args.late_minutes)
        row["ts"] = now.isoformat(timespec="milliseconds")
        row["quantity"] = int(row["quantity"])
        row["unit_price"] = float(row["unit_price"])
        row["discount"] = float(row["discount"])
        futures.append(producer.send(args.topic, key=row["store_id"], value=row))
        if sent % 50 == 0:
            print(f"da gui {sent} ban ghi, ts={row['ts']}", flush=True)
        sent += 1
        time.sleep(args.sleep)

producer.flush()
per_partition = Counter(fut.get(timeout=30).partition for fut in futures)
print("so ban ghi theo partition:", dict(sorted(per_partition.items())))
print(f"hoan tat phat su kien: {sent} ban ghi")
