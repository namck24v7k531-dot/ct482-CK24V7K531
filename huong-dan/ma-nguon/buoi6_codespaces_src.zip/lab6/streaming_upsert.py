"""Structured Streaming + foreachBatch: upsert kết quả cửa sổ vào SQLite (Buổi 6 - CT482).

Bảng đích: /tmp/lab6/retail_agg.db (trong container spark-master, nơi chạy driver).
Khóa nghiệp vụ: (window_start, category).
"""
import os
import sqlite3
import time

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, expr, from_json, sum as _sum, count as _count, window

DB = "/tmp/lab6/retail_agg.db"
CHECKPOINT = "hdfs://namenode:9000/user/student/retail_stream/chk_upsert"

spark = SparkSession.builder.appName("RetailUpsert").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

schema = ("transaction_id STRING, customer_id STRING, product_id STRING, "
          "category STRING, quantity INT, unit_price DOUBLE, discount DOUBLE, "
          "store_id STRING, region STRING, ts STRING")

raw = (spark.readStream.format("kafka")
       .option("kafka.bootstrap.servers", "kafka:9092")
       .option("subscribe", "retail-transactions")
       .option("startingOffsets", "latest")   # chỉ có tác dụng ở lần chạy ĐẦU; lần sau đọc offset từ checkpoint
       .load())

parsed = (raw.selectExpr("CAST(value AS STRING) AS json_str")
          .select(from_json(col("json_str"), schema).alias("d"))
          .select("d.*")
          .withColumn("event_time", col("ts").cast("timestamp"))
          .withColumn("revenue", expr("quantity * unit_price * (1 - discount)")))

agg = (parsed
       .withWatermark("event_time", "2 minutes")
       .groupBy(window(col("event_time"), "5 minutes"), col("category"))
       .agg(_count("*").alias("n_txn"),
            _sum("revenue").alias("total_revenue"),
            _sum("quantity").alias("total_qty")))


def upsert_batch(batch_df, batch_id):
    rows = batch_df.collect()          # kết quả tổng hợp nhỏ (vài chục dòng) nên collect về driver được
    if not rows:
        return
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS agg_result (
            window_start TEXT, window_end TEXT, category TEXT,
            n_txn INTEGER, total_revenue REAL, total_qty INTEGER,
            last_batch INTEGER,
            PRIMARY KEY (window_start, category))
    """)
    for r in rows:
        cur.execute("""
            INSERT INTO agg_result VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(window_start, category) DO UPDATE SET
                window_end=excluded.window_end, n_txn=excluded.n_txn,
                total_revenue=excluded.total_revenue, total_qty=excluded.total_qty,
                last_batch=excluded.last_batch
        """, (str(r["window"]["start"]), str(r["window"]["end"]), r["category"],
              r["n_txn"], r["total_revenue"], r["total_qty"], batch_id))
    conn.commit()
    conn.close()
    print(f"batch {batch_id}: da upsert {len(rows)} dong", flush=True)


query = (agg.writeStream
         .outputMode("update")
         .foreachBatch(upsert_batch)
         .option("checkpointLocation", CHECKPOINT)
         .trigger(processingTime="10 seconds")
         .start())

# Theo dõi tiến trình: số bản ghi vào, số dòng bị loại vì quá watermark, giá trị watermark hiện tại
last_seen = -1
while query.isActive:
    time.sleep(5)
    for p in query.recentProgress:
        if p["batchId"] <= last_seen:
            continue
        last_seen = p["batchId"]
        if p["numInputRows"] == 0:
            continue
        dropped = sum(op.get("numRowsDroppedByWatermark", 0) for op in p.get("stateOperators", []))
        print(f"  [tien trinh] batch {p['batchId']}: input={p['numInputRows']}, "
              f"bi loai do watermark={dropped}, watermark={p['eventTime'].get('watermark')}", flush=True)
