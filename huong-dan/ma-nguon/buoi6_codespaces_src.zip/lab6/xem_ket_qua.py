"""Xem bảng đích SQLite của streaming_upsert.py (chạy trong container spark-master)."""
import sqlite3
import sys

conn = sqlite3.connect("/tmp/lab6/retail_agg.db")
cur = conn.cursor()
print("so dong (khoa window_start, category):", cur.execute("SELECT COUNT(*) FROM agg_result").fetchone()[0])
print("tong n_txn trong bang:", cur.execute("SELECT SUM(n_txn) FROM agg_result").fetchone()[0])
print("theo cua so:")
for row in cur.execute("""SELECT window_start, COUNT(*) AS n_category, SUM(n_txn) AS n_txn,
                                 ROUND(SUM(total_revenue)) AS revenue, MAX(last_batch) AS last_batch
                          FROM agg_result GROUP BY window_start ORDER BY window_start"""):
    print("  ", row)
if len(sys.argv) > 1:   # python3 xem_ket_qua.py chitiet  -> in thêm 10 dòng mới cập nhật nhất
    for row in cur.execute("SELECT * FROM agg_result ORDER BY last_batch DESC, window_start DESC LIMIT 10"):
        print("  ", row)
conn.close()
