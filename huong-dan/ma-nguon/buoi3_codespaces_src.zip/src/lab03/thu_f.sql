USE retail_dw;
SELECT COUNT(*) AS n_dim FROM product_dim;
SHOW TABLES;
