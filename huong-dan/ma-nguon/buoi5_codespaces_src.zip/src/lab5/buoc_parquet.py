"""Buổi 5: chuyển CSV -> Parquet, so sánh dung lượng, thời gian, pushdown."""
import time
from pyspark.sql import SparkSession, functions as F
from schema_retail import RETAIL_SCHEMA, CSV_PATH, PARQUET_PATH

spark = SparkSession.builder.appName("Buoi5_Parquet").getOrCreate()
csv_df = (spark.read.option("header", True).schema(RETAIL_SCHEMA)
          .option("timestampFormat", "yyyy-MM-dd HH:mm:ss").csv(CSV_PATH))

# 1) Ghi Parquet (nén snappy mặc định) và Parquet phân vùng theo tháng
t0 = time.time()
csv_df.write.mode("overwrite").parquet(PARQUET_PATH)
print(f"Ghi Parquet: {time.time() - t0:.1f} s")
t0 = time.time()
(csv_df.withColumn("month", F.date_format("ts", "yyyy-MM"))
       .write.mode("overwrite").partitionBy("month").parquet(PARQUET_PATH + "_by_month"))
print(f"Ghi Parquet partitionBy(month): {time.time() - t0:.1f} s")

pq_df = spark.read.parquet(PARQUET_PATH)
pqm_df = spark.read.parquet(PARQUET_PATH + "_by_month")
print("So dong CSV / Parquet:", csv_df.count(), "/", pq_df.count())


def truy_van(df):
    return (df.filter(F.col("region") == "CanTho")
              .groupBy("category").agg(F.sum("quantity").alias("sl")))


def do_thoi_gian(ten, df, lan=3):
    truy_van(df).collect()                         # lượt làm nóng
    t0 = time.time()
    for _ in range(lan):
        truy_van(df).collect()                     # mỗi lần tạo DataFrame mới (xem 💡 bên dưới)
    print(f"{ten:<28} {(time.time() - t0) / lan:6.2f} s/lan")


do_thoi_gian("CSV (schema tuong minh)", csv_df)
do_thoi_gian("Parquet", pq_df)

# 2) Kế hoạch thực thi: column pruning + predicate pushdown + partition pruning
pq_df.filter(F.col("region") == "CanTho").select("category", "quantity").explain()
pqm_df.filter("month = '2025-03' AND region = 'CanTho'").select("category").explain()
print("Dong thang 2025-03:", pqm_df.filter("month = '2025-03'").count())
spark.stop()
