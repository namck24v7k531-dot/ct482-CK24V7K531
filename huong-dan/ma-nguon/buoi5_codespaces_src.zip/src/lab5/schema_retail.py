"""Schema tường minh dùng chung cho các script Buổi 5."""
from pyspark.sql.types import (StructType, StructField, StringType,
                               IntegerType, DoubleType, TimestampType)

RETAIL_SCHEMA = StructType([
    StructField("transaction_id", StringType(), False),
    StructField("customer_id", StringType(), True),
    StructField("product_id", StringType(), True),
    StructField("category", StringType(), True),
    StructField("quantity", IntegerType(), True),
    StructField("unit_price", DoubleType(), True),
    StructField("discount", DoubleType(), True),
    StructField("store_id", StringType(), True),
    StructField("region", StringType(), True),
    StructField("ts", TimestampType(), True),
])
CSV_PATH = "hdfs://namenode:9000/data/raw/retail_transactions.csv"
PARQUET_PATH = "hdfs://namenode:9000/user/student/parquet/transactions"
