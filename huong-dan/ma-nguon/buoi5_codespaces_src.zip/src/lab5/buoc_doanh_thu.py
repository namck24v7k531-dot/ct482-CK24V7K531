"""Buổi 5: DataFrame với schema tường minh, doanh thu theo tháng và khu vực."""
import time
from pyspark.sql import SparkSession, functions as F
from schema_retail import RETAIL_SCHEMA, CSV_PATH

spark = SparkSession.builder.appName("Buoi5_DoanhThu").getOrCreate()
print("ANSI mode:", spark.conf.get("spark.sql.ansi.enabled"))

df = (spark.read.option("header", True)
      .option("mode", "PERMISSIVE")
      .option("timestampFormat", "yyyy-MM-dd HH:mm:ss")
      .schema(RETAIL_SCHEMA)
      .csv(CSV_PATH)
      .withColumn("region", F.trim("region")))
df.printSchema()

t0 = time.time()
df.cache()
print("Tong so dong:", df.count(), f"({time.time() - t0:.1f} s, lan dau doc CSV + cache)")
print("So dong co ts NULL:", df.filter(F.col("ts").isNull()).count())

revenue = (df.withColumn("net_amount",
                         F.col("quantity") * F.col("unit_price") * (1 - F.col("discount")))
             .withColumn("month", F.date_format("ts", "yyyy-MM")))

by_month_region = (revenue.groupBy("month", "region")
    .agg(F.round(F.sum("net_amount"), 0).cast("long").alias("total_revenue"),
         F.count("transaction_id").alias("so_giao_dich"))
    .orderBy("month", F.desc("total_revenue")))
by_month_region.show(10, truncate=False)

out = "hdfs://namenode:9000/user/student/output/revenue_by_month_region"
by_month_region.coalesce(1).write.mode("overwrite").option("header", True).csv(out)

# Kiểm chứng: tổng các khu vực trong tháng 2025-03 == tổng tính trực tiếp
a = by_month_region.filter("month = '2025-03'").agg(F.sum("total_revenue")).first()[0]
b = revenue.filter("month = '2025-03'").agg(F.round(F.sum("net_amount"), 0).cast("long")).first()[0]
print(f"Kiem chung 2025-03: {a:,.0f} vs {b:,.0f} -> chenh lech {abs(a - b):,.0f}")
spark.stop()
