"""Buổi 5: Spark SQL — temp view, JOIN với bảng sản phẩm, hàm cửa sổ, ANSI-safe."""
from pyspark.sql import SparkSession
from schema_retail import PARQUET_PATH

spark = SparkSession.builder.appName("Buoi5_SparkSQL").getOrCreate()
spark.read.parquet(PARQUET_PATH).createOrReplaceTempView("giao_dich")
(spark.read.option("header", True).option("inferSchema", True)
      .csv("hdfs://namenode:9000/data/raw/products.csv")
      .createOrReplaceTempView("san_pham"))
spark.sql("SHOW VIEWS").show()
spark.sql("DESCRIBE san_pham").show()

top_brand = spark.sql("""
    WITH dt AS (
        SELECT g.region, p.brand,
               SUM(g.quantity * g.unit_price * (1 - g.discount)) AS doanh_thu
        FROM giao_dich g JOIN san_pham p ON g.product_id = p.product_id
        GROUP BY g.region, p.brand
    )
    SELECT region, brand, CAST(ROUND(doanh_thu) AS BIGINT) AS doanh_thu, hang
    FROM (SELECT *, RANK() OVER (PARTITION BY region ORDER BY doanh_thu DESC) AS hang FROM dt)
    WHERE hang <= 3
    ORDER BY region, hang
""")
top_brand.show(21, truncate=False)
top_brand.explain()

# Tỉ lệ giảm giá trung bình theo danh mục: dùng try_divide để an toàn với ANSI
spark.sql("""
    SELECT category,
           ROUND(TRY_DIVIDE(SUM(quantity * unit_price * discount),
                            SUM(quantity * unit_price)) * 100, 2) AS pct_giam_gia,
           COUNT_IF(discount > 0) AS so_don_co_giam_gia
    FROM giao_dich GROUP BY category ORDER BY pct_giam_gia DESC
""").show()
spark.stop()
