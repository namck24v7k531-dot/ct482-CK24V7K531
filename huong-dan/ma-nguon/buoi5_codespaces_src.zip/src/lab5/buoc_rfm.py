"""Buổi 5: RFM bằng DataFrame API và Spark SQL, đối chiếu kết quả và kế hoạch."""
from pyspark.sql import SparkSession, functions as F
from schema_retail import PARQUET_PATH

spark = SparkSession.builder.appName("Buoi5_RFM").getOrCreate()
revenue = (spark.read.parquet(PARQUET_PATH)
           .withColumn("net_amount",
                       F.col("quantity") * F.col("unit_price") * (1 - F.col("discount"))))

ref_date = revenue.agg(F.to_date(F.max("ts"))).first()[0]      # datetime.date
print("Ngay moc:", ref_date)

# Cách 1: DataFrame API
rfm_df = (revenue.groupBy("customer_id")
          .agg(F.datediff(F.lit(ref_date), F.max("ts")).alias("recency"),
               F.countDistinct("transaction_id").alias("frequency"),
               F.round(F.sum("net_amount"), 0).cast("long").alias("monetary")))

# Cách 2: Spark SQL trên temp view
revenue.createOrReplaceTempView("giao_dich")
rfm_sql = spark.sql(f"""
    SELECT customer_id,
           DATEDIFF(DATE'{ref_date}', MAX(ts))   AS recency,
           COUNT(DISTINCT transaction_id)      AS frequency,
           CAST(ROUND(SUM(net_amount), 0) AS BIGINT) AS monetary
    FROM giao_dich
    GROUP BY customer_id
""")

rfm_df.orderBy(F.desc("monetary")).show(5)
rfm_sql.orderBy(F.desc("monetary")).show(5)

print("So khach hang:", rfm_df.count(), "/", rfm_sql.count())
diff = rfm_df.exceptAll(rfm_sql).count() + rfm_sql.exceptAll(rfm_df).count()
print("So dong khac nhau giua 2 cach:", diff)
print("Cung ngu nghia (sameSemantics):", rfm_df.sameSemantics(rfm_sql))
rfm_df.explain()
rfm_sql.explain()

# Chấm điểm R, F, M (1..4) theo tứ phân vị xấp xỉ (không cần cửa sổ toàn cục)
qs = rfm_df.approxQuantile(["recency", "frequency", "monetary"], [0.25, 0.5, 0.75], 0.01)
print("Tu phan vi recency/frequency/monetary:", qs)


def diem(cot, q, dao_nguoc=False):
    d = (F.when(F.col(cot) <= q[0], 1).when(F.col(cot) <= q[1], 2)
          .when(F.col(cot) <= q[2], 3).otherwise(4))
    return (5 - d) if dao_nguoc else d       # recency càng nhỏ càng tốt -> đảo điểm


seg = (rfm_df.withColumn("R", diem("recency", qs[0], dao_nguoc=True))
             .withColumn("F", diem("frequency", qs[1]))
             .withColumn("M", diem("monetary", qs[2])))
(seg.groupBy("R").agg(F.count("*").alias("so_kh"),
                      F.round(F.avg("frequency"), 1).alias("frequency_tb"),
                      F.round(F.avg("monetary"), 0).cast("long").alias("monetary_tb"))
    .orderBy(F.desc("R")).show())
seg.write.mode("overwrite").parquet("hdfs://namenode:9000/user/student/output/rfm")
print("Da ghi /user/student/output/rfm")
spark.stop()
