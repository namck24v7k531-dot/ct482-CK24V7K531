"""Spark 4.1 đọc/ghi MongoDB bằng MongoDB Spark Connector 11.x (Scala 2.13)."""
from pyspark.sql import SparkSession, functions as F

spark = (SparkSession.builder.appName("Buoi4_Spark_MongoDB")
         .config("spark.mongodb.read.connection.uri", "mongodb://mongodb:27017")
         .config("spark.mongodb.write.connection.uri", "mongodb://mongodb:27017")
         .getOrCreate())

df = (spark.read.format("mongodb")
      .option("database", "retail").option("collection", "transactions")
      .load())
df.printSchema()

# Bộ lọc được đẩy xuống MongoDB (predicate pushdown) -> chỉ đọc document của CanTho
cantho = df.filter(F.col("store.region") == "CanTho")
cantho.select("_id", "category").explain()
print("So giao dich CanTho:", cantho.count())

kq = (cantho.groupBy("category")
      .agg(F.round(F.sum(F.col("quantity") * F.col("unit_price") * (1 - F.col("discount"))), 0)
           .alias("doanh_thu"), F.count("*").alias("so_don"))
      .orderBy(F.desc("doanh_thu")))
kq.show()

(kq.write.format("mongodb").mode("overwrite")
   .option("database", "retail").option("collection", "doanh_thu_cantho_theo_danh_muc")
   .save())
print("Da ghi", kq.count(), "dong vao retail.doanh_thu_cantho_theo_danh_muc")
spark.stop()
