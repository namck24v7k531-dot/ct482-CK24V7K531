// Hàm tóm tắt kết quả explain("executionStats") của một truy vấn find
function tomTat(q) {
  const e = db.transactions.find(q).explain("executionStats");
  const wp = e.queryPlanner.winningPlan.queryPlan || e.queryPlanner.winningPlan;
  const st = JSON.stringify(wp);
  return {
    cac_stage: st.match(/"stage":"(\w+)"/g).map(x => x.slice(9, -1)).join(" > "),
    chi_muc: (st.match(/"indexName":"([^"]+)"/) || [null, "-"])[1],
    so_ket_qua: e.executionStats.nReturned,
    so_doc_da_quet: e.executionStats.totalDocsExamined,
    so_khoa_da_quet: e.executionStats.totalKeysExamined,
    thoi_gian_ms: e.executionStats.executionTimeMillis
  };
}
