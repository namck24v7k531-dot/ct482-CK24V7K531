import csv
from collections import Counter
from rowkey import salt, salted_key, time_first_key

print(salted_key("D00001", "2025-06-01 00:00:05"))
print(time_first_key("D00001", "2025-06-01 00:00:05"))

thiet_bi, dong = Counter(), Counter()
devices = set()
with open("/data/sensor_readings.csv") as f:
    for r in csv.DictReader(f):
        devices.add(r["device_id"])
        dong[salt(r["device_id"])] += 1
for d in devices:
    thiet_bi[salt(d)] += 1

print("So thiet bi:", len(devices), "- so dong:", sum(dong.values()))
print("bucket  so_thiet_bi  so_dong")
for b in sorted(dong):
    print(f"   {b}      {thiet_bi[b]:5d}     {dong[b]:6d}")
print("Lech (max/min so dong):", round(max(dong.values()) / min(dong.values()), 3))
