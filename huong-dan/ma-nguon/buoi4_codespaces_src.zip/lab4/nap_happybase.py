"""Nạp sensor_readings.csv vào HBase qua Thrift (happybase), ghi theo lô."""
import csv, sys, time
import happybase
from rowkey import salted_key, time_first_key

BANG = sys.argv[1]                                  # iot_sensor_data | iot_time_first
N = int(sys.argv[2]) if len(sys.argv) > 2 else 10**9
tao_khoa = salted_key if BANG == "iot_sensor_data" else time_first_key

conn = happybase.Connection("hbase", 9090)          # Thrift server trong container hbase
table = conn.table(BANG)
t0 = time.time()
n = 0
with open("/data/sensor_readings.csv") as f, table.batch(batch_size=2000) as b:
    for r in csv.DictReader(f):
        if n >= N:
            break
        b.put(tao_khoa(r["device_id"], r["ts"]).encode(), {
            b"cf:temperature": r["temperature"].encode(),
            b"cf:humidity": r["humidity"].encode(),
            b"cf:pm25": r["pm25"].encode(),
            b"cf:battery": r["battery"].encode(),
        })
        n += 1
print(f"{BANG}: da nap {n} dong trong {time.time() - t0:.1f} giay")
conn.close()
