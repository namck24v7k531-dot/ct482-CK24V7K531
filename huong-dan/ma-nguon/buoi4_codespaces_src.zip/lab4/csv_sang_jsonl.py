"""Chuyển retail_transactions.csv -> retail_transactions.jsonl (mỗi dòng 1 document)."""
import csv, json, sys, time

N = int(sys.argv[1]) if len(sys.argv) > 1 else None      # tuỳ chọn: chỉ lấy N dòng đầu
t0, n = time.time(), 0
with open("/data/retail_transactions.csv", encoding="utf-8") as fin, \
     open("/data/retail_transactions.jsonl", "w", encoding="utf-8") as fout:
    for row in csv.DictReader(fin):
        if N is not None and n >= N:
            break
        doc = {
            "_id": row["transaction_id"],                 # dùng mã giao dịch làm khóa chính
            "customer_id": row["customer_id"],
            "product_id": row["product_id"],
            "category": row["category"],
            "quantity": int(row["quantity"]),
            "unit_price": float(row["unit_price"]),
            "discount": float(row["discount"]),
            "store": {"store_id": row["store_id"], "region": row["region"]},   # document lồng
            "ts": {"$date": row["ts"].replace(" ", "T") + "+07:00"},           # kiểu Date thật
        }
        fout.write(json.dumps(doc, ensure_ascii=False) + "\n")
        n += 1
print(f"Da ghi {n} document vao /data/retail_transactions.jsonl trong {time.time() - t0:.1f} giay")
