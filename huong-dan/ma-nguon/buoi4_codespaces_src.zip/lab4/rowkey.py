"""Thiết kế row key cho dữ liệu cảm biến (Buổi 4)."""
import hashlib

SO_BUCKET = 16          # 1 ký tự hexa: 0..f


def salt(device_id: str) -> str:
    """Tiền tố băm: ký tự hexa đầu tiên của MD5(device_id)."""
    return hashlib.md5(device_id.encode()).hexdigest()[0]


def ts_compact(ts: str) -> str:
    """'2025-06-01 00:00:05' -> '20250601000005' (sắp xếp được theo thời gian)."""
    return ts.replace("-", "").replace(" ", "").replace(":", "")


def salted_key(device_id: str, ts: str) -> str:
    """Khóa có salt: <salt>#<device_id>#<yyyyMMddHHmmss>."""
    return f"{salt(device_id)}#{device_id}#{ts_compact(ts)}"


def time_first_key(device_id: str, ts: str) -> str:
    """Khóa 'ngây thơ' đặt thời gian lên đầu: <yyyyMMddHHmmss>#<device_id>."""
    return f"{ts_compact(ts)}#{device_id}"
