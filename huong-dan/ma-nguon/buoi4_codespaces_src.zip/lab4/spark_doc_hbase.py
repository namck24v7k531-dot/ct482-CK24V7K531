"""Spark 4 đọc HBase song song theo 16 bucket salt (thay cho connector hbase-spark)."""
from pyspark.sql import SparkSession, functions as F, types as T

spark = SparkSession.builder.appName("Buoi4_Spark_doc_HBase").getOrCreate()
sc = spark.sparkContext
BUCKETS = list("0123456789abcdef")


def quet_bucket(buckets):
    import happybase                       # import trong executor (nodemanager1/2)
    conn = happybase.Connection("hbase", 9090)
    table = conn.table("iot_sensor_data")
    for b in buckets:
        for key, d in table.scan(row_prefix=f"{b}#".encode(), batch_size=5000):
            _, device_id, ts = key.decode().split("#")
            yield (device_id, ts, float(d[b"cf:temperature"]), float(d[b"cf:humidity"]),
                   float(d[b"cf:pm25"]), int(d[b"cf:battery"]))
    conn.close()


schema = T.StructType([
    T.StructField("device_id", T.StringType()), T.StructField("ts", T.StringType()),
    T.StructField("temperature", T.DoubleType()), T.StructField("humidity", T.DoubleType()),
    T.StructField("pm25", T.DoubleType()), T.StructField("battery", T.IntegerType())])

rdd = sc.parallelize(BUCKETS, len(BUCKETS)).mapPartitions(quet_bucket)   # 16 task = 16 bucket
df = (spark.createDataFrame(rdd, schema)
      .withColumn("ts", F.to_timestamp("ts", "yyyyMMddHHmmss")))
df.cache()
print("So dong doc tu HBase:", df.count(), "- so partition:", df.rdd.getNumPartitions())
df.printSchema()

(df.groupBy(F.to_date("ts").alias("ngay"))
   .agg(F.count("*").alias("so_ban_ghi"),
        F.round(F.avg("temperature"), 2).alias("nhiet_do_tb"),
        F.round(F.avg("pm25"), 2).alias("pm25_tb"))
   .orderBy("ngay").show())

(df.groupBy("device_id").agg(F.round(F.avg("pm25"), 1).alias("pm25_tb"), F.count("*").alias("n"))
   .orderBy(F.desc("pm25_tb")).show(5))
spark.stop()
