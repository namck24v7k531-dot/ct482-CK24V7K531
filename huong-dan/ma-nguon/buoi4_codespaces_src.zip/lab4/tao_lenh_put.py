"""Sinh tệp lệnh HBase shell (put) từ N dòng đầu của sensor_readings.csv."""
import csv, sys
from rowkey import salted_key

N = int(sys.argv[1]) if len(sys.argv) > 1 else 2000
with open("/data/sensor_readings.csv") as fin, open("/src/lab4/load_iot.hbase", "w") as fout:
    for i, r in enumerate(csv.DictReader(fin)):
        if i >= N:
            break
        k = salted_key(r["device_id"], r["ts"])
        for col in ("temperature", "humidity", "pm25", "battery"):
            fout.write(f"put 'iot_sensor_data', '{k}', 'cf:{col}', '{r[col]}'\n")
    fout.write("exit\n")
print(f"Da ghi {N} dong ({4 * N} lenh put) vao /src/lab4/load_iot.hbase")
