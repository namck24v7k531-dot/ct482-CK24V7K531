"""Đọc HBase từ Python qua Thrift (happybase)."""
import happybase
from rowkey import salt

conn = happybase.Connection("hbase", 9090)
print("Cac bang:", [t.decode() for t in conn.tables()])
table = conn.table("iot_sensor_data")

# 1) get theo row key day du
row = table.row(b"4#D00177#20250601000000")
print("get:", {k.decode(): v.decode() for k, v in row.items()})

# 2) scan 1 thiet bi trong 1 ngay: tinh tien to salt roi quet theo khoang khoa
dev = "D00001"
start = f"{salt(dev)}#{dev}#20250601".encode()
stop = f"{salt(dev)}#{dev}#20250602".encode()
temps = [float(d[b"cf:temperature"]) for _, d in
         table.scan(row_start=start, row_stop=stop, columns=[b"cf:temperature"])]
print(f"{dev} ngay 2025-06-01: {len(temps)} ban ghi, nhiet do TB = {sum(temps) / len(temps):.2f}")

# 3) put + delete mot o du lieu
table.put(b"0#TEST#20250101000000", {b"cf:temperature": b"99.9"})
print("sau put:", table.row(b"0#TEST#20250101000000"))
table.delete(b"0#TEST#20250101000000")
print("sau delete:", table.row(b"0#TEST#20250101000000"))
conn.close()
