"""Truy cập MongoDB từ Python bằng pymongo."""
import time
from datetime import datetime, timezone, timedelta
from pymongo import MongoClient, ASCENDING

VN = timezone(timedelta(hours=7))
# tz_aware + tzinfo: trả datetime theo giờ Việt Nam (mặc định pymongo trả giờ UTC "naive")
client = MongoClient("mongodb://mongodb:27017", tz_aware=True, tzinfo=VN)   # từ host: mongodb://localhost:27017
db = client["retail"]
tx = db["transactions"]
print("MongoDB", client.server_info()["version"], "- so document:", tx.estimated_document_count())

# 1) find có điều kiện + projection + sort + limit
q = {"store.region": "DaNang", "ts": {"$gte": datetime(2025, 8, 1, tzinfo=VN)}}
for d in tx.find(q, {"_id": 1, "category": 1, "ts": 1}).sort("ts", ASCENDING).limit(3):
    print(d)

# 2) aggregate: doanh thu theo danh mục (category)
t0 = time.time()
pipeline = [
    {"$group": {"_id": "$category",
                "doanh_thu": {"$sum": {"$multiply": ["$quantity", "$unit_price",
                                                     {"$subtract": [1, "$discount"]}]}},
                "so_don": {"$sum": 1}}},
    {"$sort": {"doanh_thu": -1}},
]
for r in tx.aggregate(pipeline, allowDiskUse=True):
    print(f"{r['_id']:<12} {r['doanh_thu']:>20,.0f} {r['so_don']:>9,}")
print(f"aggregate mat {time.time() - t0:.1f} giay")

# 3) ghi: insert_many + update_many + delete_many trên collection tạm
tmp = db["tmp_demo"]
tmp.drop()
tmp.insert_many([{"sku": f"P{i:05d}", "ton_kho": i * 10} for i in range(1, 6)])
r = tmp.update_many({"ton_kho": {"$lt": 30}}, {"$set": {"can_nhap": True}})
print("update_many matched/modified:", r.matched_count, r.modified_count)
print("delete_many deleted:", tmp.delete_many({"can_nhap": True}).deleted_count,
      "- con lai:", tmp.count_documents({}))
client.close()
