"""Suy luận theo lô (batch inference) bằng PipelineModel đã lưu — Buổi 7, CT482.

Chạy như một ứng dụng ĐỘC LẬP với phiên huấn luyện:
  spark-submit --master spark://spark-master:7077 /src/lab7/churn_score.py
"""
from pyspark.sql import SparkSession, functions as F
from pyspark.ml import PipelineModel
from pyspark.ml.functions import vector_to_array

MODEL_PATH = "hdfs://namenode:9000/models/churn_pipeline_v1"
INPUT_PATH = "hdfs://namenode:9000/user/student/lab7/new_customers"
OUTPUT_PATH = "hdfs://namenode:9000/output/churn_scores_v1"

spark = SparkSession.builder.appName("ChurnBatchScoring").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

model = PipelineModel.load(MODEL_PATH)
print("cac stage:", [type(s).__name__ for s in model.stages])

new_batch = spark.read.parquet(INPUT_PATH)
print("so khach hang can cham diem:", new_batch.count(), "| co cot churn_label?", "churn_label" in new_batch.columns)

scores = (model.transform(new_batch)
          .withColumn("churn_prob", F.round(vector_to_array("probability")[1], 4))
          .select("customer_id", "recency_days", "frequency", "prediction", "churn_prob"))

scores.write.mode("overwrite").parquet(OUTPUT_PATH)

result = spark.read.parquet(OUTPUT_PATH)
result.groupBy("prediction").count().orderBy("prediction").show()
print("10 khach hang co nguy co roi bo cao nhat:")
result.orderBy(F.desc("churn_prob")).show(10)
spark.stop()
